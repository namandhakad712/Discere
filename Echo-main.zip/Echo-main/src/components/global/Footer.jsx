
function Footer() {
  return (
    <footer className="bg-stone-800 shadow-md w-full ">

    </footer>
  );
}
export default Footer;
